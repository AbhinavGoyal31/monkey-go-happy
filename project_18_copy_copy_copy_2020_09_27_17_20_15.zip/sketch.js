var bananaImage,obstacleImage,backImage,player_running;
var obstacleGroup,bananaGroup;
var player,score,ground,back;

function preload(){
  
backImage     =loadImage ("jungle.jpg");
bananaImage   = loadImage("banana.png");  
obstacleImage = loadImage("stone.png");
player_running =                                                   loadAnimation ("Monkey_01.png","Monkey_02.png", "Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png", "Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
    
}
  
function setup() {
  createCanvas(400,400);
 ground = createSprite(200,350,750,10); 
 ground.velocityX=-6;
 ground.x=ground.width/2;
  ground.visible = false; 
 back = createSprite(200,200,0,0);
 back.addImage("back",backImage); 
 back.x=back.width/2;
  
 payer = createSprite(350,0,0,0);
 player.addAnimation("running",player_running);
 player.scale=0.3;
  
 var obstacleGroup = createGroup();
 var bananaGroup = createGroup();
  
 }

 function draw() {
 
  
  if(keyDown("space")) {
   player.velocityY = -10;
  }
  
 player.velocityY = player.velocityY + 0.8
  
  if (ground.x < 0){
    ground.x = ground.width/2;
  }
  if (back.x < 0){
    back.x =back.width/2;
  }
   if(foodGroup.isTouching (player)){
   score=score+2;
   foodGroup.destroyEach;  
   }
   if(obstacleGroup.isTouching (player)){
   player.scale=0.2;
    
   } 
  addscale();
  obstacle();
  food();
  drawSprites();
    background(180);
  stroke("white");
  textSize(20);
  fill("white");
  score =score + Math.round(getFrameRate()/60);
  text("Score: "+ score, 500, 50);
 }
 function obstacle() {
 if (World.frameCount%300===0) {
  var stone= createSprite(400, 200,20,20);
 stone.scale=0.1;
 stone.y=randomNumber(120,200);
 stone.addAnimation("Stone",obstacleImage);
 stone.scale=0.15;
 stone.velocityX=-7;
 obstacleGroup.setLifetimeEach(100);
 obstacleGroup.add(stone);  
 

 }
 }
 function food() {
 if (World.frameCount%80===0) {
  var banana= createSprite(400, 200,20,20);
 banana.scale=0.05;
 banana.y=randomNumber(120,200);
 banana.addAnimation("Banana");
 banana.scale=0.100;
 banana.velocityX=-7;
 bananaGroup.setLifetimeEach(100);
 bananaGroup.add(banana);  
 

 }
 }

 function addscale() {
 switch(score){
  case 10: player.scale=0.12;
   break;
  case 20: player.scale=0.14;
   break; 
  case 30: player.scale=0.16;
   break; 
  case 40: player.scale=0.18;
   break; 
   default:break;
 }
 }

